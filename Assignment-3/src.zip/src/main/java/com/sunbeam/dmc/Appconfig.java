package com.sunbeam.dmc;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.annotation.Bean;

@Configurable
public class Appconfig {
	 @Bean
	    public BoxImpl b1() {
	    	BoxImpl b = new BoxImpl();
	    	b.setNum1(50);
	    	b.setNum2(25);
	    	
	    	return b;
	    }
	    
	    @Bean
	    public BoxImpl b2() {
	    	BoxImpl b = new BoxImpl(10, 8);
	    	return b;
	    }
}
