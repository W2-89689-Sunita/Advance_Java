package com.sunbeam.dmc;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class SpringAssignment2Appl {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(Appconfig.class);
		
		//Addition
		BoxImpl b1 = (BoxImpl) ctx.getBean("b1");
		int add = b1.calcAddition();
		System.out.println("b1 Addition: "+add);
		
		/*
		 BoxImpl b2 = (BoxImpl) ctx.getBean("b2");
		 
		int add1 = b2.calcAddition();
		System.out.println("b2 Addition: "+add1);
		*/
		
		//Subtraction
		BoxImpl b2 = (BoxImpl) ctx.getBean("b1");
		int sub = b2.calcSubtraction();
		System.out.println("b1 Subtraction: "+sub);
		
		//Multiplication
		BoxImpl b3 = (BoxImpl) ctx.getBean("b1");
		int mul = b3.calcMultiplication();
		System.out.println("b1 Multiplication: "+mul);
		
		//Division
		BoxImpl b4 = (BoxImpl) ctx.getBean("b1");
		int div = b4.calcDivision();
		System.out.println("b1 Division: "+div);
	}

}
