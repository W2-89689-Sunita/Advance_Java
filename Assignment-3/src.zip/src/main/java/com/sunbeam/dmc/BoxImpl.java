package com.sunbeam.dmc;

public class BoxImpl {
   private int num1;
   private int num2;

   
   public BoxImpl() {
	
}


public BoxImpl(int num1, int num2) {
	super();
	this.num1 = num1;
	this.num2 = num2;
}


   public int getNum1() {
	return num1;
}


   public void setNum1(int num1) {
	this.num1 = num1;
}


   public int getNum2() {
	return num2;
}


   public void setNum2(int num2) {
	this.num2 = num2;
}


@Override
   public String toString() {
	return "BoxImpl [num1=" + num1 + ", num2=" + num2 + "]";
}
  
   public int calcAddition() {
	return this.num1 + this.num2;
}
   
  public int calcSubtraction() {
	return this.num1 - this.num2;
}

  public int calcDivision() {
		return this.num1 / this.num2;
	}
  public int calcMultiplication() {
		return this.num1 * this.num2;
	}
}
